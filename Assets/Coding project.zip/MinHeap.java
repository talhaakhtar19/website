import java.util.Scanner;

public class MinHeap {
	
	// Variable Declarations
	private int[] heap;
    private int size;
    private int capacity;
    private Scanner in = new Scanner(System.in);

    // Initialize the Heap with 50 nodes
    public MinHeap() {
        this.capacity = 50;
        this.size = 0;
        this.heap = new int[capacity];
    }

    // Method to get the parent index
    private int parent(int i) {
    	return (i - 1) / 2;
    }

    // Method to get the left child index
    private int leftChild(int i) {
    	return 2 * i + 1;
    }

    // Method to get the right child index
    private int rightChild(int i) {
    	return 2 * i + 2;
    }

    // Method to swap two elements in the heap
    private void swap(int i, int j) {
        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    // Method to ensure the heap property is maintained while inserting
    private void heapifyUp(int i) {
        while (i != 0 && heap[parent(i)] > heap[i]) {
            swap(i, parent(i));
            i = parent(i);
        }
    }

    // Method to ensure the heap property is maintained while removing
    private void heapifyDown(int i) {
        int smallest = i;
        int left = leftChild(i);
        int right = rightChild(i);

        if (left < size && heap[left] < heap[smallest]) {
            smallest = left;
        }

        if (right < size && heap[right] < heap[smallest]) {
            smallest = right;
        }

        if (smallest != i) {
            swap(i, smallest);
            heapifyDown(smallest);
        }
    }

    // Method to insert a new element into the heap
    public void insert(int key) {
        if (size == capacity) {
            throw new RuntimeException("Heap is full");
        }
        heap[size] = key;
        size++;
        heapifyUp(size - 1);
    }

    // Method to extract the minimum element from the heap
    public int extractMin() {
        if (size <= 0) {
            throw new RuntimeException("Heap is empty");
        }
        if (size == 1) {
            size--;
            return heap[0];
        }

        int root = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);

        return root;
    }
    
    // Main method to call in Driver class
    public void runProgram() {
    	while(true) {
    		System.out.println("\nWhat do you want to do with the Min Heap?");
        	System.out.println("1. Insert");
        	System.out.println("2. ExtractMin");
        	System.out.println("3. Exit");
        	System.out.print("Enter your choice: ");
        	int choice = in.nextInt();
        	System.out.println();
        	if(choice == 1) {
        		while(true) {
        			System.out.print("Enter the key to insert into the Min Heap (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				this.insert(inp);
        			}
        		}
        	}
        	else if(choice == 2) {
        		System.out.println("Min element extracted: " + this.extractMin());
        	}
        	else if(choice == 3) {
        		break;
        	}
        	else {
        		System.out.println("Error. Please enter 1/2/3\n");
        	}
    	}
    }
}