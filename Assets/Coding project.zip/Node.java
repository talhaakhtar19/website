import java.util.Scanner;

public class Node {
	
	// Variable Declarations
	private int data;
	private Node next;
	private Scanner in = new Scanner(System.in);
	
	// Initialize with Head and next Nodes
	public Node (int d, Node n) {
		this.data = d;
		this.next = n;
	}
	
    // Insert a new node to the back
    public void insert(int newData) {
    	Node newNode = new Node(newData, null);
        Node current = this;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    // Delete a node with the specified key
    public void delete(int del) {
    	Node current = this;
        while (current.next != null) {
            if (current.next.data == del) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    // Traverse through node and print each element
    public void traverse() {
        Node current = this;
        while (current != null) {
            System.out.print(current.data);
            if(current.next != null) {
            	System.out.print(" -> ");
            }
            current = current.next;
        }
        System.out.println();
    }
    
    // Main output method to call in Driver Class
    public void runProgram() {
    	// Ask for head value once
    	System.out.print("Set Head Value: ");
    	Node user = new Node(in.nextInt(), null);
    	while(true) {
    		System.out.println("\nWhat do you want to do with the linked list?");
        	System.out.println("1. Add Data");
        	System.out.println("2. Delete Data");
        	System.out.println("3. Display Linked List");
        	System.out.println("4. Exit");
        	System.out.print("Enter your choice: ");
        	int choice = in.nextInt();
        	System.out.println();
        	if(choice == 1) {
        		while(true) {
        			System.out.print("Enter the data to add to the Linked List (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				user.insert(inp);
        			}
        		}
        	}
        	else if(choice == 2) {
        		while(true) {
        			System.out.print("Enter the data to remove from the Linked List (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				user.delete(inp);
        			}
        		}
        	}
        	else if(choice == 3) {
        		System.out.println("Your Linked List looks like this:");
        		user.traverse();
        	}
        	else if(choice == 4) {
        		break;
        	}
        	else {
        		System.out.println("Error. Please enter 1/2/3/4\n");
        	}
    	}
    }
}