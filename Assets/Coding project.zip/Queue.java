import java.util.Scanner;

public class Queue {
	
	// Variable Declarations
	private int[] queueArray;
    private int front;
    private int rear;
    private int currentSize;
    private int capacity;
    private Scanner in = new Scanner(System.in);
    
    // Initialize with Capacity for one element
    public Queue() {
        capacity = 1;
        queueArray = new int[capacity];
        front = 0;
        rear = -1;
        currentSize = 0;
    }
    
    // Add capacity to the Queue for more elements
    private void expandCapacity() {
        int newCapacity = capacity * 2;
        int[] newArray = new int[newCapacity];
        for (int i = 0; i < currentSize; i++) {
            newArray[i] = queueArray[(front + i) % capacity];
        }
        queueArray = newArray;
        front = 0;
        rear = currentSize - 1;
        capacity = newCapacity;
    }
    
    // Add element to the back of Queue
    public void enqueue(int item) {
        if (currentSize == capacity) {
            expandCapacity();
        }
        rear = (rear + 1) % capacity;
        queueArray[rear] = item;
        currentSize++;
    }
    
    // Remove element from the front of the queue
    public int dequeue() {
        if (currentSize == 0) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return -1; // Or throw an exception
        }
        int removedItem = queueArray[front];
        front = (front + 1) % capacity;
        currentSize--;
        return removedItem;
    }
    
    // Main Method to call in Driver Class
    public void runProgram() {
    	while(true) {
    		System.out.println("\nWhat do you want to do with the Stack?");
        	System.out.println("1. Enqueue");
        	System.out.println("2. Dequeue");
        	System.out.println("3. Exit");
        	System.out.print("Enter your choice: ");
        	int choice = in.nextInt();
        	System.out.println();
        	if(choice == 1) {
        		while(true) {
        			System.out.print("Enter the data to enqueue (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				this.enqueue(inp);
        			}
        		}
        	}
        	else if(choice == 2) {
        		System.out.println("Dequeued element: " + this.dequeue());
        	}
        	else if(choice == 3) {
        		break;
        	}
        	else {
        		System.out.println("Error. Please enter 1/2/3\n");
        	}
    	}
    }
}