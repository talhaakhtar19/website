import java.util.Scanner;

public class BinarySearchTree {
	
	// Inner class representing a node in the BST
    private class TreeNode {
    	
    	// Private Class Variable Declarations
        int key;
        TreeNode left, right;
        
        // Initialize the Tree-style Node with left-right pointers
        public TreeNode(int item) {
            key = item;
            left = right = null;
        }
    }
    
    // Variable Declarations
    private TreeNode root;
    private Scanner in = new Scanner(System.in);

    // Initialize BST with a root and empty TreeNode
    public BinarySearchTree() {
        root = null;
    }
    
    // Getter Method to obtain Minimum value
    private int minValue(TreeNode root) {
        int minValue = root.key;
        while (root.left != null) {
            root = root.left;
            minValue = root.key;
        }
        return minValue;
    }
    
    // Helper Method to Recursively insert into BST
    private TreeNode insertRecursive(TreeNode root, int key) {
        if (root == null) {
            root = new TreeNode(key);
            return root;
        }
        if (key < root.key) {
            root.left = insertRecursive(root.left, key);
        } else if (key > root.key) {
            root.right = insertRecursive(root.right, key);
        }
        return root;
    }
    
    // Helper Method to delete a key in BST
    private TreeNode deleteRecursive(TreeNode root, int key) {
        if (root == null) {
            return root;
        }
        if (key < root.key) {
            root.left = deleteRecursive(root.left, key);
        } else if (key > root.key) {
            root.right = deleteRecursive(root.right, key);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            root.key = minValue(root.right);
            root.right = deleteRecursive(root.right, root.key);
        }
        return root;
    }
    
    // Helper Method to find element in BST
    private TreeNode findRecursive(TreeNode root, int key) {
        if (root == null || root.key == key) {
            return root;
        }
        if (root.key < key) {
            return findRecursive(root.right, key);
        }
        return findRecursive(root.left, key);
    }
    
    // Helper Method to traverse through BST
    private void inorderRecursive(TreeNode root) {
        if (root != null) {
            inorderRecursive(root.left);
            System.out.print(root.key + " -> ");
            inorderRecursive(root.right);
        }
    }

    // Insert new element into BST
    public void insert(int key) {
        root = insertRecursive(root, key);
    }

    // Delete element from BST
    public void delete(int key) {
        root = deleteRecursive(root, key);
    }

    // Find an element in BST
    public void find(int key) {
        if(findRecursive(root, key) != null) {
        	System.out.println("Node found in the BST.");
        }
        else {
        	System.out.println("Node not found in the BST.");
        }
    }

    // Traverse through BST in order
    public void inorder() {
        inorderRecursive(root);
    }
    
    // Main Method to call in Driver Class
    public void runProgram() {
    	while(true) {
    		System.out.println("\nWhat do you want to do with the BST?");
        	System.out.println("1. Insert Node");
        	System.out.println("2. Delete Node");
        	System.out.println("3. Find Node");
        	System.out.println("4. Inorder Traversal");
        	System.out.println("5. Exit");
        	System.out.print("Enter your choice: ");
        	int choice = in.nextInt();
        	System.out.println();
        	if(choice == 1) {
        		while(true) {
        			System.out.print("Enter the key to insert into the BST (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				this.insert(inp);
        			}
        		}
        	}
        	else if(choice == 2) {
        		while(true) {
        			System.out.print("Enter the key to delete from the BST (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				this.delete(inp);
        			}
        		}
        	}
        	else if(choice == 3) {
        		System.out.print("Enter the key to find in the BST: ");
        		this.find(in.nextInt());
        	}
        	else if(choice == 4) {
        		System.out.println("Inorder Traversal of the BST:");
        		this.inorder();
        		System.out.println();
        	}
        	else if(choice == 5) {
        		break;
        	}
        	else {
        		System.out.println("Error. Please enter 1/2/3/4/5\n");
        	}
    	}
    }
}