import java.util.Scanner;

public class Stack {
	
	// Variable Declarations
	private int capacity;
    private int[] stackArray;
    private int topLevel;
    private Scanner in = new Scanner(System.in);
    
    // Initialize with the Capacity for one element
    public Stack() {
        capacity = 1;
        stackArray = new int[capacity];
        topLevel = -1;
    }
    
    // Add capacity to the Stack for more elements
    private void expandCapacity() {
        int newCapacity = capacity * 2;
        int[] newStackArray = new int[newCapacity];
        System.arraycopy(stackArray, 0, newStackArray, 0, capacity);
        stackArray = newStackArray;
        capacity = newCapacity;
    }
    
    // Add element to the Stack
    public void push(int value) {
        if (topLevel == capacity - 1) {
            expandCapacity();
        }
        topLevel++;
        stackArray[topLevel] = value;
    }
    
    // Remove top element from Stack
    public int pop() {
        if (topLevel == -1) {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1;
        }
        int poppedValue = stackArray[topLevel];
        topLevel--;
        return poppedValue;
    }
    
    // Return top value of the Stack
    public int top() {
        if (topLevel == -1) {
            System.out.println("Stack is empty. No elements to peek.");
            return -1;
        }
        return stackArray[topLevel];
    }
    
    // Main output method to call in Driver Class
    public void runProgram() {
    	while(true) {
    		System.out.println("\nWhat do you want to do with the Stack?");
        	System.out.println("1. Push Element");
        	System.out.println("2. Pop Element");
        	System.out.println("3. Top Element");
        	System.out.println("4. Exit");
        	System.out.print("Enter your choice: ");
        	int choice = in.nextInt();
        	System.out.println();
        	if(choice == 1) {
        		while(true) {
        			System.out.print("Enter the data to push onto the Stack (-1 to end): ");
        			int inp = in.nextInt();
        			if(inp == -1) {
        				break;
        			}
        			else {
        				this.push(inp);
        			}
        		}
        	}
        	else if(choice == 2) {
        		System.out.println("Popped element: " + this.pop());
        	}
        	else if(choice == 3) {
        		System.out.println("Top element: " + this.top());
        	}
        	else if(choice == 4) {
        		break;
        	}
        	else {
        		System.out.println("Error. Please enter 1/2/3/4\n");
        	}
    	}
    }
}