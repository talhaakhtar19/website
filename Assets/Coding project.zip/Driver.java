import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		
		//Variable Declarations
		Node linkedList = new Node(0,null);
		Stack stack = new Stack();
		Queue queue = new Queue();
		MinHeap minHeap = new MinHeap();
		BinarySearchTree bst = new BinarySearchTree();
		Scanner user = new Scanner(System.in);
		
		// User selects the Data Structure, code implements the corresponding interface
		while(true) {
			System.out.println("Program: Please select the data structure you want to work with:");
			System.out.println("Enter 1 for Linked List");
			System.out.println("Enter 2 for Stack");
			System.out.println("Enter 3 for Queue");
			System.out.println("Enter 4 for Min Heap");
			System.out.println("Enter 5 for Binary Search Tree (BST)");
			int choice = user.nextInt();
			
			// Linked List
			if(choice == 1) {
				System.out.println("You've selected Linked List");
				linkedList.runProgram();
			}
			
			// Stack
			else if(choice == 2) {
				System.out.println("You've selected Stack");
				stack.runProgram();
			}
			
			// Queue
			else if(choice == 3) {
				System.out.println("You've selected Queue");
				queue.runProgram();
			}
			
			// Min Heap
			else if(choice == 4) {
				System.out.println("You've selected Min Heap");
				minHeap.runProgram();
			}
			
			// BST
			else if(choice == 5) {
				System.out.println("You've selected Binary Search Tree (BST)");
				bst.runProgram();
			}
			
			// Invalid choice (< 1 or > 5) end Program
			else {
				System.out.println("Program Terminated");
				break;
			}
		}
	}
}